-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.1.35-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura para tabela aeronave.aeronave
CREATE TABLE IF NOT EXISTS `aeronave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefixo` varchar(50) NOT NULL,
  `tipo` enum('P','C') NOT NULL,
  `horas_voo` decimal(7,2) NOT NULL,
  `ano_fabricacao` varchar(10) NOT NULL,
  `status` enum('A','D') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.aeronave: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `aeronave` DISABLE KEYS */;
INSERT INTO `aeronave` (`id`, `prefixo`, `tipo`, `horas_voo`, `ano_fabricacao`, `status`) VALUES
	(1, 'teste-2', 'C', 15021.11, '1996', 'A'),
	(2, 'teste-3', 'C', 15021.11, '1996', 'A');
/*!40000 ALTER TABLE `aeronave` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.login
CREATE TABLE IF NOT EXISTS `login` (
  `ind` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  PRIMARY KEY (`ind`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.login: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`ind`, `nome`, `email`, `password`) VALUES
	(1, 'gabriel', 'adm@teste.com', '4f22a5b713259a8b3e6d47c9073d7eef25e6ced4c20cbe49abaaa2e80b01e4e37c1a7c16891810668dd9a6bd88f259bbf8b7a672d37e785c3f2f3aa0b7169b54');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.manutencao
CREATE TABLE IF NOT EXISTS `manutencao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tecnico` int(11) NOT NULL,
  `id_aeronave` int(11) NOT NULL,
  `tipo` enum('P','C') NOT NULL,
  `data_hora` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('A','D') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tecnico` (`id_tecnico`),
  KEY `id_aeronave` (`id_aeronave`),
  CONSTRAINT `manutencao_ibfk_1` FOREIGN KEY (`id_tecnico`) REFERENCES `tecnico` (`id`),
  CONSTRAINT `manutencao_ibfk_2` FOREIGN KEY (`id_aeronave`) REFERENCES `aeronave` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.manutencao: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `manutencao` DISABLE KEYS */;
INSERT INTO `manutencao` (`id`, `id_tecnico`, `id_aeronave`, `tipo`, `data_hora`, `status`) VALUES
	(1, 2, 2, 'C', '2000-02-23 12:23:56', 'D'),
	(2, 1, 1, 'P', '2000-02-23 12:23:56', 'A'),
	(3, 1, 1, 'P', '2000-02-23 12:23:56', 'A'),
	(4, 1, 1, 'P', '2000-02-23 12:23:56', 'D'),
	(5, 1, 1, 'P', '2000-02-23 12:23:56', 'A'),
	(6, 2, 2, 'C', '2000-02-23 12:23:56', 'A'),
	(9, 2, 2, 'C', '2000-02-23 12:23:56', 'D'),
	(10, 2, 2, 'C', '2000-02-23 12:23:56', 'D');
/*!40000 ALTER TABLE `manutencao` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.missao
CREATE TABLE IF NOT EXISTS `missao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_partida` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data_chegada` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tipo` enum('P','C') NOT NULL,
  `id_piloto` int(11) NOT NULL,
  `id_copiloto` int(11) NOT NULL,
  `id_aeronave` int(11) NOT NULL,
  `status` enum('A','D') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_piloto` (`id_piloto`),
  KEY `id_aeronave` (`id_aeronave`),
  KEY `missao_3` (`id_copiloto`),
  CONSTRAINT `missao_1` FOREIGN KEY (`id_piloto`) REFERENCES `piloto` (`id`),
  CONSTRAINT `missao_2` FOREIGN KEY (`id_aeronave`) REFERENCES `aeronave` (`id`),
  CONSTRAINT `missao_3` FOREIGN KEY (`id_copiloto`) REFERENCES `piloto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.missao: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `missao` DISABLE KEYS */;
INSERT INTO `missao` (`id`, `data_partida`, `data_chegada`, `tipo`, `id_piloto`, `id_copiloto`, `id_aeronave`, `status`) VALUES
	(9, '2018-11-10 09:53:27', '2018-12-26 20:53:33', 'P', 2, 4, 2, 'A'),
	(10, '2018-11-08 09:03:17', '2018-11-11 20:53:33', 'P', 3, 5, 2, 'A');
/*!40000 ALTER TABLE `missao` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.piloto
CREATE TABLE IF NOT EXISTS `piloto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `sobre_nome` varchar(50) NOT NULL,
  `cpf` varchar(50) NOT NULL,
  `data_nascimento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sexo` enum('M','F') NOT NULL,
  `qualificacao` enum('P','C') NOT NULL,
  `ultimo_exame` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `telefone` varchar(22) NOT NULL,
  `endereco` varchar(200) NOT NULL,
  `status` enum('A','D') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.piloto: ~9 rows (aproximadamente)
/*!40000 ALTER TABLE `piloto` DISABLE KEYS */;
INSERT INTO `piloto` (`id`, `nome`, `sobre_nome`, `cpf`, `data_nascimento`, `sexo`, `qualificacao`, `ultimo_exame`, `telefone`, `endereco`, `status`) VALUES
	(1, 'novonome2', 'vieira', '95272640063', '2018-11-08 08:22:32', '', 'P', '2018-11-08 08:22:32', '21999999999', '', 'A'),
	(2, 'novonome3', 'vieira', '18540831805', '2018-11-08 07:32:19', 'F', 'P', '2018-11-08 07:32:19', '21991459285', 'sdadsad', 'A'),
	(3, 'novonome3', 'vieira', '27243653804', '2018-11-08 08:22:01', 'F', 'P', '2018-11-08 08:22:01', '21991459285', 'sdadsad', 'A'),
	(4, 'novonome3', 'vieira', '43184679373', '2018-11-08 07:26:21', 'F', 'C', '2018-11-08 07:26:21', '21991459285', 'sdadsad', 'A'),
	(5, 'novonome3', 'vieira', '45389006216', '2018-11-08 08:22:42', 'F', 'C', '2018-11-08 08:22:42', '21991459285', 'sdadsad', 'A'),
	(6, 'novonome3', 'vieira', '58211618869', '1996-10-23 06:02:24', 'F', '', '2016-10-23 06:02:24', '21991459285', 'sdadsad', 'A'),
	(7, 'novonome3', 'vieira', '54366562774', '1998-10-23 06:02:24', 'F', '', '2016-10-23 06:02:24', '21991459285', 'sdadsad', 'A'),
	(8, 'novonome3', 'vieira', '72142751474', '1998-10-23 06:02:24', 'F', '', '2016-10-23 06:02:24', '21991459285', 'sdadsad', 'A'),
	(9, 'novonome3', 'vieira', '89901651050', '1998-10-23 06:02:24', 'F', '', '2016-10-23 06:02:24', '21991459285', 'sdadsad', 'A');
/*!40000 ALTER TABLE `piloto` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.tecnico
CREATE TABLE IF NOT EXISTS `tecnico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `data_nascimento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sexo` enum('M','F') NOT NULL,
  `naturalidade` varchar(100) NOT NULL,
  `exame_medico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `qualificacao` varchar(20) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `endereco` varchar(200) NOT NULL,
  `status` enum('A','D') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.tecnico: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
INSERT INTO `tecnico` (`id`, `nome`, `data_nascimento`, `sexo`, `naturalidade`, `exame_medico`, `qualificacao`, `telefone`, `endereco`, `status`) VALUES
	(1, 'novo-2', '2018-11-06 22:57:28', 'M', '', '2018-11-06 22:57:28', 'teste', '21988083149', 'teste', 'A'),
	(2, 'teste-2', '2000-02-02 19:07:26', 'M', '', '2018-11-07 19:07:26', 'teste', '21988083149', 'teste', 'A');
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
